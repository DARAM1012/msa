import javax.xml.namespace.QName;

public class BankAccount {

    private String name;
    private int num;
    int num2 = 0;


    public int Account(String name,int num,int num2){
       this.name = name;
       this.num = num;
       this.num2 = num2;

        System.out.println("계좌번호" + this.name);
        System.out.println("잔액" + this.num2);
        return num2;
    }
    public void deposit(int a){
        num2 += a;
    }
    public void withdraw(int a){
        num2 -= a;
    }
}
