package com.example.eurekaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
